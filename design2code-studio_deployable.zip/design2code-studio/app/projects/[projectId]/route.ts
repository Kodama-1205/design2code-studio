import { NextResponse } from "next/server";
import { getProject } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(_req: Request, { params }: { params: { projectId: string } }) {
  try {
    const project = await getProject(params.projectId);

    if (!project) {
      return NextResponse.json(
        { error: "not_found", message: "プロジェクトが見つかりませんでした。" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { id: project.id, name: project.name, source_url: project.source_url },
      { status: 200 }
    );
  } catch (e: any) {
    return NextResponse.json(
      { error: "server_error", message: e?.message ?? "不明なエラー" },
      { status: 500 }
    );
  }
}
