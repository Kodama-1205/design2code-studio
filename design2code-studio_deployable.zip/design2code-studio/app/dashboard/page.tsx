import { listProjects } from "@/lib/db";
import Card from "@/components/ui/Card";
import Button from "@/components/ui/Button";
import EmptyState from "@/components/EmptyState";

export const runtime = "nodejs";

export default async function Page() {
  let projects: Awaited<ReturnType<typeof listProjects>> = [];
  let saveDisabled = false;

  try {
    projects = await listProjects();
  } catch {
    saveDisabled = true;
  }

  return (
    <div className="container-max py-10">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="h1">ダッシュボード</h1>
          <p className="p-muted mt-2">保存済みプロジェクト（生成履歴）を一覧表示します。</p>
        </div>

        {/* ページ内に同じ導線を増やさない：右上にだけ置く */}
        <div className="flex gap-2">
          <Button href="/new" variant="primary">
            新規作成
          </Button>
          <Button href="/" variant="secondary">
            TOPへ
          </Button>
        </div>
      </div>

      {saveDisabled && (
        <div className="mt-6 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-800 dark:text-amber-200">
          <strong>保存機能は現在ご利用いただけません。</strong>{" "}
          Supabase の接続制限などによりプロジェクト一覧の取得に失敗しています。右上の「新規作成」では生成自体は試せます。
        </div>
      )}

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {projects.length === 0 ? (
          <div className="sm:col-span-2 lg:col-span-3">
            <EmptyState
              title="まだプロジェクトがありません"
              description={
                saveDisabled
                  ? "保存は無効のため、まずは右上の「新規作成」で生成をお試しください。"
                  : "右上の「新規作成」からFigma URLを貼り付けて生成してください。"
              }
              actionHref="/new"
              actionLabel="新規作成"
            />
          </div>
        ) : (
          projects.map((p) => {
            const sourceUrl = p.source_url ?? "";

            // ✅ 再生成リンク：projectId + sourceUrl を同梱（URL消失対策）
            const regenHref = `/new?projectId=${encodeURIComponent(p.id)}&sourceUrl=${encodeURIComponent(sourceUrl)}`;

            // 開く（最新生成があれば結果へ、なければ再生成へ）
            const openHref = p.last_generation_id
              ? `/projects/${p.id}/generations/${p.last_generation_id}`
              : regenHref;

            return (
              <Card key={p.id} className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-base font-semibold truncate">{p.name}</div>
                    <div className="p-muted mt-1 truncate">{sourceUrl}</div>
                  </div>
                  <span className="badge">Figma</span>
                </div>

                <div className="mt-4 text-xs text-[rgb(var(--muted))]">
                  <div>FileKey: {p.figma_file_key}</div>
                  <div>NodeId: {p.figma_node_id}</div>
                </div>

                <div className="mt-5 flex gap-2">
                  <Button href={regenHref} variant="ghost">
                    再生成
                  </Button>
                  <Button href={openHref} variant="secondary">
                    開く
                  </Button>
                </div>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
