import crypto from "crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import {
  createOrUpdateProject,
  createGeneration,
  saveGenerationArtifacts,
  setGenerationStatus
} from "@/lib/db";
import { runMockPipeline } from "@/lib/mockPipeline";
import { buildDemoBundle } from "@/lib/demoBundle";
import { DEMO_OWNER_ID } from "@/lib/env";
import { getSupabaseAdmin } from "@/lib/supabaseAdmin";

export const runtime = "nodejs";

const BodySchema = z.object({
  sourceUrl: z.string().min(10),
  profileId: z.string().uuid().optional(),
  projectId: z.string().uuid().optional(),
  // ✅ ユーザーが都度入力（DBには保存しない）
  figmaToken: z.string().min(10).optional()
});

/**
 * node-id を「保存用」と「API用」に分ける
 * - 保存用: URLのdecodedをほぼそのまま（例: "10-55" も保持）
 * - API用  : Images APIで通りやすい形へ正規化（"10-55" -> "10:55"）
 */
function normalizeNodeIdForApi(nodeId: string): string {
  // すでに ":" が含まれていればそのまま
  if (nodeId.includes(":")) return nodeId;
  // "10-55" のような形式は ":" に寄せる（Images APIの互換性目的）
  if (nodeId.includes("-")) return nodeId.replace("-", ":");
  return nodeId;
}

/**
 * Figma URL から fileKey / nodeId を抽出
 * - /file/ と /design/ の両形式に対応
 * - node-id が無い場合は "0:0"
 */
function parseFigmaUrl(sourceUrl: string): {
  figmaFileKey: string;
  figmaNodeId: string; // 保存用
  figmaNodeIdForApi: string; // Images API用
  parseOk: boolean;
} {
  const fileKeyMatch = sourceUrl.match(/figma\.com\/(?:file|design)\/([^/?#]+)/);
  const nodeIdMatch = sourceUrl.match(/[?&]node-id=([^&]+)/);

  const figmaFileKey = fileKeyMatch?.[1] ?? "UNKNOWN_FILEKEY";

  let figmaNodeId = "0:0";
  let figmaNodeIdForApi = "0:0";

  if (nodeIdMatch?.[1]) {
    const decoded = decodeURIComponent(nodeIdMatch[1]);
    // 例: "10%3A55" -> "10:55" になる場合もあるので一応置換
    figmaNodeId = decoded.replace("%3A", ":");
    figmaNodeIdForApi = normalizeNodeIdForApi(figmaNodeId);
  }

  const parseOk = Boolean(fileKeyMatch?.[1]);
  return { figmaFileKey, figmaNodeId, figmaNodeIdForApi, parseOk };
}

/**
 * Figma Images API でサムネURL取得（最大30日で失効）
 * - token は保存しない（この関数内だけで使用）
 */
async function fetchFigmaPreviewUrl(input: {
  figmaFileKey: string;
  figmaNodeIdForApi: string;
  figmaToken: string;
}): Promise<{ previewUrl: string | null; debug?: { status: number; hasImagesKey: boolean } }> {
  const { figmaFileKey, figmaNodeIdForApi, figmaToken } = input;

  if (!figmaFileKey || figmaFileKey === "UNKNOWN_FILEKEY") {
    return { previewUrl: null, debug: { status: 0, hasImagesKey: false } };
  }
  if (!figmaNodeIdForApi || figmaNodeIdForApi === "0:0") {
    return { previewUrl: null, debug: { status: 0, hasImagesKey: false } };
  }

  const url =
    `https://api.figma.com/v1/images/${encodeURIComponent(figmaFileKey)}` +
    `?ids=${encodeURIComponent(figmaNodeIdForApi)}` +
    `&format=png&scale=1`;

  const res = await fetch(url, {
    headers: { "X-Figma-Token": figmaToken },
    cache: "no-store"
  });

  const status = res.status;

  const json = (await res.json().catch(() => null)) as any;
  const images = json?.images;
  const hasImagesKey = Boolean(images && typeof images === "object");

  if (!res.ok || !hasImagesKey) {
    return { previewUrl: null, debug: { status, hasImagesKey } };
  }

  const previewUrl = images?.[figmaNodeIdForApi];
  if (typeof previewUrl === "string" && previewUrl.length > 10) {
    return { previewUrl, debug: { status, hasImagesKey } };
  }

  return { previewUrl: null, debug: { status, hasImagesKey } };
}

/**
 * ✅ 取得したPNGを Supabase Storage(d2c-previews) に保存（非Public想定）
 * - key: `${projectId}/${snapshotHash}.png`
 * - 失敗しても生成自体は成功させる（プレビューは任意）
 */
async function savePreviewToStorage(input: {
  projectId: string;
  snapshotHash: string;
  previewUrl: string;
}): Promise<{ storagePath: string } | null> {
  const supabaseAdmin = getSupabaseAdmin();
  if (!supabaseAdmin) return null;

  const { projectId, snapshotHash, previewUrl } = input;

  const fileName = snapshotHash.endsWith(".png") ? snapshotHash : `${snapshotHash}.png`;
  const storagePath = `${projectId}/${fileName}`;

  const imgRes = await fetch(previewUrl, { cache: "no-store" });
  if (!imgRes.ok) return null;

  const ab = await imgRes.arrayBuffer();
  const bytes = new Uint8Array(ab);

  const { error } = await supabaseAdmin.storage
    .from("d2c-previews")
    .upload(storagePath, bytes, { contentType: "image/png", upsert: true });

  if (error) return null;

  return { storagePath };
}

export async function POST(req: Request) {
  const json = await req.json().catch(() => null);
  const parsed = BodySchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "リクエスト形式が不正です。",
        message: "sourceUrl（必須）/ profileId / projectId / figmaToken の形式を確認してください。",
        details: parsed.error.flatten()
      },
      { status: 400 }
    );
  }

  const { sourceUrl, profileId, projectId, figmaToken } = parsed.data;

  const { figmaFileKey, figmaNodeId, figmaNodeIdForApi, parseOk } = parseFigmaUrl(sourceUrl);

  const projectName = `Project ${figmaFileKey.slice(0, 6)} / ${figmaNodeId}`;

  let project:
    | {
        id: string;
        owner_id: string;
        name: string;
        figma_file_key: string;
        figma_node_id: string;
        source_url: string;
      }
    | null = null;

  let generation: { id: string; project_id: string } | null = null;

  // --- 1) DBに project/generation を作る（保存モード） ---
  try {
    project = await createOrUpdateProject({
      id: projectId,
      name: projectName,
      figma_file_key: figmaFileKey,
      figma_node_id: figmaNodeId, // ✅ 保存用（ハイフンでも保持）
      source_url: sourceUrl,
      default_profile_id: profileId ?? null
    });

    generation = await createGeneration({
      project_id: project.id,
      profile_id: profileId ?? null
    });

    await setGenerationStatus(generation.id, "running", { started_at: new Date().toISOString() });
  } catch {
    // DB保存に失敗 → デモモード
    const tempProjectId = crypto.randomUUID();
    const tempGenerationId = crypto.randomUUID();

    const artifacts = await runMockPipeline({
      figmaFileKey,
      figmaNodeId,
      sourceUrl,
      profileOverrideId: profileId ?? undefined,
      projectId: tempProjectId,
      generationId: tempGenerationId
    });

    const bundle = buildDemoBundle(
      tempProjectId,
      tempGenerationId,
      {
        name: projectName,
        figma_file_key: figmaFileKey,
        figma_node_id: figmaNodeId,
        source_url: sourceUrl,
        owner_id: DEMO_OWNER_ID
      },
      artifacts
    );

    return NextResponse.json(
      {
        saved: false,
        bundle,
        warnings: [
          "保存に失敗したため、デモモードで結果を返しました。",
          "Supabase 環境変数（URL / Secret key / Owner ID）やDBテーブル作成状況を確認してください。"
        ]
      },
      { status: 200 }
    );
  }

  // --- 2) パイプライン実行 → artifacts をDBに保存 ---
  try {
    const artifacts = await runMockPipeline({
      figmaFileKey,
      figmaNodeId,
      sourceUrl,
      profileOverrideId: profileId ?? undefined,
      projectId: project!.id,
      generationId: generation!.id
    });

    // ✅ サムネ取得（任意：トークンがある時だけ）
    const hasToken = Boolean(figmaToken && figmaToken.trim().length >= 10);

    const { previewUrl, debug } = hasToken
      ? await fetchFigmaPreviewUrl({
          figmaFileKey,
          figmaNodeIdForApi, // ✅ API用（10-55 -> 10:55）
          figmaToken: figmaToken!.trim()
        })
      : { previewUrl: null, debug: undefined };

    // ✅ 一時URLが取れたらPNGをStorageへ
    const savedPreview =
      previewUrl && project?.id
        ? await savePreviewToStorage({
            projectId: project.id,
            snapshotHash: artifacts.snapshotHash,
            previewUrl
          }).catch(() => null)
        : null;

    const mergedReport = {
      ...(artifacts.report ?? {}),
      ...(savedPreview
        ? {
            preview_storage: {
              bucket: "d2c-previews",
              path: savedPreview.storagePath
            },
            preview_fetched_at: new Date().toISOString(),
            preview_note:
              "プレビュー画像はFigmaから取得してSupabase Storageに保存します。画像が無い場合はトークン/権限/node-id/バケットを確認し、再生成で再取得してください。"
          }
        : {}),
      // ✅ デバッグ（トークンは絶対入れない）
      preview_debug: {
        figma_node_id_saved: figmaNodeId,
        figma_node_id_api: figmaNodeIdForApi,
        figma_file_key: figmaFileKey === "UNKNOWN_FILEKEY" ? "UNKNOWN_FILEKEY" : `${figmaFileKey.slice(0, 6)}...`,
        ...(debug ? { figma_images_api: debug } : {})
      }
    };

    await saveGenerationArtifacts({
      projectId: project!.id,
      generationId: generation!.id,
      profileSnapshot: artifacts.profileSnapshot,
      irJson: artifacts.ir,
      reportJson: mergedReport,
      files: artifacts.files,
      mappings: artifacts.mappings,
      snapshotHash: artifacts.snapshotHash
    });

    await setGenerationStatus(generation!.id, "succeeded", { finished_at: new Date().toISOString() });

    const warnings: string[] = [];
    if (!parseOk || figmaFileKey === "UNKNOWN_FILEKEY") {
      warnings.push("Figma URL から fileKey を正しく解析できませんでした（/file/ または /design/ 形式か確認してください）。");
    }
    if (hasToken && !previewUrl) {
      warnings.push("Figma Images API からプレビューURLを取得できませんでした（トークン/権限/node-id を確認してください）。");
    }
    if (hasToken && previewUrl && !savedPreview) {
      warnings.push("プレビューPNGのStorage保存に失敗しました（Supabase Storage のバケット/権限を確認してください）。");
    }

    return NextResponse.json(
      {
        saved: true,
        projectId: project!.id,
        generationId: generation!.id,
        ...(warnings.length ? { warnings } : {})
      },
      { status: 200 }
    );
  } catch (e: any) {
    try {
      await setGenerationStatus(generation!.id, "failed", {
        finished_at: new Date().toISOString(),
        error_json: { message: e?.message ?? "不明なエラー" }
      });
    } catch {
      // 握りつぶし
    }

    return NextResponse.json(
      {
        error: "生成に失敗しました。",
        message: e?.message ? `処理中にエラーが発生しました：${e.message}` : "処理中に不明なエラーが発生しました。"
      },
      { status: 500 }
    );
  }
}
